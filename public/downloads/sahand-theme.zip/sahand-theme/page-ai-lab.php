<?php
/**
 * Template Name: AI Research Lab
 *
 * @package SahandTheme
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
$current_lang = function_exists('sahand_get_current_lang') ? sahand_get_current_lang() : 'fa';
?>

<main id="primary" class="site-main" style="background-color: var(--color-canvas-dark); color: #FFFFFF; min-height: 80vh; padding-block: 4rem 6rem; position: relative;">
  
  <!-- Neural Data Flow Background -->
  <?php get_template_part('template-parts/components/neural-data-flow', null, array('variant' => 'neural', 'theme' => 'dark')); ?>

  <div class="sahand-container" style="position: relative; z-index: 2;">
    
    <header style="margin-bottom: 3.5rem; border-bottom: 1px solid var(--color-border-dark); padding-bottom: 2rem;">
      <div class="badge badge-tech" style="margin-bottom: 1rem; display: inline-block;">
        <span>AI LAB // GEMINI 3.8 SERVER GATEWAY</span>
      </div>
      <h1 style="font-size: clamp(2rem, 4vw, 3rem); font-weight: 800; letter-spacing: -0.02em;">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('آزمایشگاه پژوهشی هوش مصنوعی و مدل‌های زبانی');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Yapay Zeka ve Büyük Dil Modelleri Araştırma Laboratuvarı');
        } else {
            echo esc_html('AI Research Lab & Neural Inference Engines');
        }
        ?>
      </h1>
      <p style="font-size: 1.125rem; color: var(--color-text-secondary-dark); max-width: 700px; margin-top: 0.75rem; line-height: 1.7;">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('سیستم‌های هوش مصنوعی مستقل، پایپ‌لاین‌های استنتاج سروری امن، و بهینه‌سازی مدل‌های زبانی برای کاربردهای مالی و داده‌کاوی.');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Finansal ve teknik uygulamalar için güvenli sunucu taraflı LLM çıkarım boru hatları ve otonom yapay zeka araçları.');
        } else {
            echo esc_html('Zero-leakage server-side AI pipelines, vector retrieval architectures, and real-time inference toolkits.');
        }
        ?>
      </p>
    </header>

    <!-- Interactive AI Gateway Console -->
    <section class="sahand-ai-console" style="background: rgba(15, 23, 42, 0.75); border: 1px solid var(--color-border-dark); border-radius: var(--radius-lg); padding: 2rem; margin-bottom: 3.5rem; backdrop-filter: blur(12px);">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; border-bottom: 1px solid var(--color-border-dark); padding-bottom: 1rem;">
        <span class="font-mono" style="font-size: 0.8125rem; color: var(--color-accent-electric); font-weight: 700;">
          GATEWAY CONSOLE // REST INFERENCE (SERVER-SIDE)
        </span>
        <span class="badge badge-stable" style="font-size: 0.75rem;">GEMINI 3.8 FLASH</span>
      </div>

      <form id="sahand-ai-form" style="display: flex; flex-direction: column; gap: 1rem;">
        <label for="ai-prompt-input" style="font-size: 0.875rem; color: var(--color-text-secondary-dark);">
          <?php esc_html_e('Enter technical query or prompt for model analysis:', 'sahand-theme'); ?>
        </label>
        <textarea id="ai-prompt-input" name="prompt" rows="3" maxlength="2000" placeholder="<?php esc_attr_e('e.g. Analyze microsecond latency characteristics in distributed matching engines...', 'sahand-theme'); ?>" style="background: rgba(0, 0, 0, 0.4); border: 1px solid var(--color-border-dark); border-radius: var(--radius-md); padding: 0.85rem; color: #FFFFFF; font-family: monospace; resize: vertical;" required></textarea>

        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
          <span id="ai-status-indicator" class="font-mono" style="font-size: 0.8125rem; color: var(--color-text-secondary-dark);">
            STATUS: READY
          </span>
          <button type="submit" id="ai-submit-btn" class="badge badge-stable" style="cursor: pointer; padding: 0.75rem 1.75rem; border: none; font-weight: 700;">
            <?php esc_html_e('Execute Inference', 'sahand-theme'); ?> ⚡
          </button>
        </div>
      </form>

      <div id="ai-response-container" style="display: none; margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid var(--color-border-dark);">
        <div style="display: flex; justify-content: space-between; font-size: 0.75rem; color: rgba(255, 255, 255, 0.45); font-family: monospace; margin-bottom: 0.5rem;">
          <span id="ai-model-label">MODEL: GEMINI 3.8 FLASH</span>
          <span id="ai-latency-label">LATENCY: --ms</span>
        </div>
        <div id="ai-response-text" class="font-mono" style="background: rgba(0, 0, 0, 0.5); padding: 1rem; border-radius: var(--radius-sm); border: 1px solid rgba(56, 189, 248, 0.2); font-size: 0.875rem; line-height: 1.6; white-space: pre-wrap; color: #E0F2FE;"></div>
      </div>
    </section>

    <!-- Registered AI Tools Grid -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 2rem;">
      <?php
      $ai_query = new WP_Query(array(
          'post_type'      => 'sahand_ai_tool',
          'post_status'    => 'publish',
          'posts_per_page' => 20,
      ));

      if ($ai_query->have_posts()) :
          while ($ai_query->have_posts()) : $ai_query->the_post();
              $post_id    = get_the_ID();
              $model      = get_post_meta($post_id, '_sahand_ai_model', true) ?: 'gemini-3.8-flash';
              $task       = get_post_meta($post_id, '_sahand_ai_task', true);
              $latency    = get_post_meta($post_id, '_sahand_ai_latency', true);
              $status     = get_post_meta($post_id, '_sahand_ai_status', true) ?: 'active';
              $demo_url   = get_post_meta($post_id, '_sahand_ai_demo_url', true);
              ?>
              <article class="sahand-card" style="background: rgba(15, 23, 42, 0.6); border: 1px solid var(--color-border-dark); color: #FFFFFF;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                  <span class="badge badge-tech font-mono"><?php echo esc_html($model); ?></span>
                  <span class="badge badge-stable" style="text-transform: uppercase; font-size: 0.75rem;"><?php echo esc_html($status); ?></span>
                </div>

                <h2 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 0.5rem;"><?php the_title(); ?></h2>
                <div style="font-size: 0.875rem; color: var(--color-text-secondary-dark); line-height: 1.6; margin-bottom: 1rem;">
                  <?php the_excerpt(); ?>
                </div>

                <div class="font-mono" style="font-size: 0.75rem; color: rgba(255, 255, 255, 0.5); display: flex; flex-direction: column; gap: 0.35rem; margin-bottom: 1rem;">
                  <?php if ($task) : ?><div>TASK: <?php echo esc_html($task); ?></div><?php endif; ?>
                  <?php if ($latency) : ?><div>LATENCY: <span style="color: var(--color-accent-electric);"><?php echo esc_html($latency); ?></span></div><?php endif; ?>
                </div>

                <?php if ($demo_url) : ?>
                  <a href="<?php echo esc_url($demo_url); ?>" target="_blank" rel="noopener noreferrer" class="badge badge-stable" style="text-decoration: none; display: inline-block;">
                    <?php esc_html_e('Interactive Playground', 'sahand-theme'); ?> →
                  </a>
                <?php endif; ?>
              </article>
              <?php
          endwhile;
          wp_reset_postdata();
      endif;
      ?>
    </div>

  </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const form = document.getElementById('sahand-ai-form');
  const input = document.getElementById('ai-prompt-input');
  const submitBtn = document.getElementById('ai-submit-btn');
  const statusIndicator = document.getElementById('ai-status-indicator');
  const container = document.getElementById('ai-response-container');
  const textElem = document.getElementById('ai-response-text');
  const latencyElem = document.getElementById('ai-latency-label');

  if (!form) return;

  form.addEventListener('submit', async function(e) {
    e.preventDefault();
    const prompt = input.value.trim();
    if (!prompt) return;

    submitBtn.disabled = true;
    statusIndicator.textContent = 'STATUS: INFERENCE IN PROGRESS...';
    statusIndicator.style.color = '#38BDF8';

    try {
      const response = await fetch('/wp-json/sahand/v1/ai/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: prompt, language: '<?php echo esc_js($current_lang); ?>' })
      });

      const data = await response.json();
      container.style.display = 'block';

      if (response.ok && data.success) {
        textElem.textContent = data.text;
        latencyElem.textContent = 'LATENCY: ' + (data.latency_ms || '--') + 'ms';
        statusIndicator.textContent = 'STATUS: COMPLETE (200 OK)';
        statusIndicator.style.color = '#10B981';
      } else {
        textElem.textContent = 'Error: ' + (data.error || 'Request failed with HTTP ' + response.status);
        statusIndicator.textContent = 'STATUS: ERROR (' + response.status + ')';
        statusIndicator.style.color = '#EF4444';
      }
    } catch (err) {
      container.style.display = 'block';
      textElem.textContent = 'Network or client error: ' + err.message;
      statusIndicator.textContent = 'STATUS: CONNECTION ERROR';
      statusIndicator.style.color = '#EF4444';
    } finally {
      submitBtn.disabled = false;
    }
  });
});
</script>

<?php
get_footer();
