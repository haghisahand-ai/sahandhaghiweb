<?php
/**
 * Generic Single Post Template
 *
 * @package SahandTheme
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
$current_lang = function_exists('sahand_get_current_lang') ? sahand_get_current_lang() : 'fa';
?>

<main id="primary" class="site-main" style="background-color: var(--color-canvas); color: var(--color-text-primary); min-height: 80vh; padding-block: 4rem 6rem;">
  <div class="sahand-container" style="max-width: 820px;">
    <?php
    while (have_posts()) : the_post();
        ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
          <header style="margin-bottom: 2.5rem; border-bottom: 1px solid var(--color-border-subtle); padding-bottom: 2rem;">
            <div class="font-mono" style="font-size: 0.8125rem; color: var(--color-text-tertiary); margin-bottom: 0.75rem;">
              <span><?php echo get_the_date('Y.m.d'); ?></span> · <span><?php echo esc_html(get_post_type()); ?></span>
            </div>
            <h1 style="font-size: clamp(2rem, 4.5vw, 3rem); font-weight: 800; line-height: 1.25;">
              <?php the_title(); ?>
            </h1>
          </header>

          <div class="entry-content" style="font-size: 1.125rem; line-height: 1.8; color: var(--color-text-secondary);">
            <?php the_content(); ?>
          </div>
        </article>
        <?php
    endwhile;
    ?>
  </div>
</main>

<?php
get_footer();
