<?php
/**
 * Archive Template for sahand_project CPT (Engineering Projects)
 *
 * @package SahandTheme
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
$current_lang = function_exists('sahand_get_current_lang') ? sahand_get_current_lang() : 'fa';
?>

<main id="primary" class="site-main" style="background-color: var(--color-canvas); color: var(--color-text-primary); padding-block: 4rem 6rem;">
  <div class="sahand-container">
    
    <header style="margin-bottom: 3.5rem; border-bottom: 1px solid var(--color-border-subtle); padding-bottom: 2rem;">
      <div class="badge badge-tech" style="margin-bottom: 1rem; display: inline-block;">
        <span>INDEX // ARCHITECTURAL REPOSITORY</span>
      </div>
      <h1 style="font-size: clamp(2.25rem, 5vw, 3.5rem); font-weight: 800; line-height: 1.2;">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('پروژه‌ها و معماری‌های مهندسی');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Mühendislik Projeleri ve Mimariler');
        } else {
            echo esc_html('Engineering Projects & Architecture');
        }
        ?>
      </h1>
      <p style="font-size: 1.125rem; color: var(--color-text-secondary); max-width: 680px; margin-top: 0.75rem; line-height: 1.7;">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('سیستم‌های توزیع‌شده، پلتفرم‌های محاسباتی با تاخیر پایین، مدل‌های یادگیری ماشین و موتورهای اجرایی.');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Dağıtık sistemler, düşük gecikmeli hesaplama platformları, makine öğrenimi modelleri ve işlem motorları.');
        } else {
            echo esc_html('Distributed systems, low-latency execution engines, financial order-flow algorithms, and resilient infrastructure.');
        }
        ?>
      </p>
    </header>

    <?php if (have_posts()) : ?>
      <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 1.75rem;">
        <?php
        while (have_posts()) : the_post();
            $post_id   = get_the_ID();
            $status    = get_post_meta($post_id, '_sahand_project_status', true) ?: 'production';
            $timeline  = get_post_meta($post_id, '_sahand_project_timeline', true);
            $problem   = get_post_meta($post_id, '_sahand_project_problem', true);
            ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('sahand-card'); ?> style="display: flex; flex-direction: column; justify-content: space-between;">
              <div>
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                  <span class="badge badge-stable" style="text-transform: uppercase; font-size: 0.75rem;">
                    <?php echo esc_html($status); ?>
                  </span>
                  <?php if ($timeline) : ?>
                    <span class="font-mono" style="font-size: 0.75rem; color: var(--color-text-tertiary);">
                      <?php echo esc_html($timeline); ?>
                    </span>
                  <?php endif; ?>
                </div>

                <h2 style="font-size: 1.35rem; font-weight: 700; margin-bottom: 0.75rem; line-height: 1.3;">
                  <a href="<?php the_permalink(); ?>" style="color: var(--color-text-primary); text-decoration: none;">
                    <?php the_title(); ?>
                  </a>
                </h2>

                <p style="font-size: 0.9375rem; line-height: 1.6; color: var(--color-text-secondary); margin-bottom: 1.25rem;">
                  <?php
                  if ($problem) {
                      echo esc_html(wp_trim_words($problem, 24));
                  } else {
                      echo esc_html(wp_trim_words(get_the_excerpt(), 24));
                  }
                  ?>
                </p>
              </div>

              <div style="padding-top: 1rem; border-top: 1px solid var(--color-border-subtle); display: flex; justify-content: space-between; align-items: center;">
                <a href="<?php the_permalink(); ?>" style="color: var(--color-accent); font-weight: 600; font-size: 0.875rem; text-decoration: none;">
                  <?php esc_html_e('Explore Project', 'sahand-theme'); ?> →
                </a>
              </div>
            </article>
            <?php
        endwhile;
        ?>
      </div>

      <div style="margin-top: 3rem; text-align: center;">
        <?php the_posts_pagination(array('mid_size' => 2)); ?>
      </div>

    <?php else : ?>
      <p style="color: var(--color-text-secondary); font-size: 1.125rem;">
        <?php esc_html_e('No engineering projects published yet.', 'sahand-theme'); ?>
      </p>
    <?php endif; ?>

  </div>
</main>

<?php
get_footer();
