<?php
/**
 * Atomic & Proxy-Safe Rate Limiter for Shared Hosting & WAF Integration
 *
 * @package SahandCore
 */

if (!defined('ABSPATH')) {
    exit;
}

class Sahand_Rate_Limiter {

    /**
     * Table name without prefix
     */
    const TABLE_NAME = 'sahand_rate_limits';

    /**
     * Cache group for object caching
     */
    const CACHE_GROUP = 'sahand_rate_limits';

    /**
     * Create the rate limits table if it does not already exist
     */
    public static function create_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            action_key varchar(40) NOT NULL,
            ip_hash varchar(64) NOT NULL,
            bucket bigint(20) unsigned NOT NULL,
            hits int(11) unsigned NOT NULL DEFAULT 1,
            expires_at bigint(20) unsigned NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY action_ip_bucket (action_key, ip_hash, bucket),
            KEY idx_expires (expires_at)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Clean up expired rate limiting entries
     */
    public static function cleanup_expired() {
        global $wpdb;
        $table_name = $wpdb->prefix . self::TABLE_NAME;
        $now = time();
        // Delete expired records (run via wp_scheduled or probabilistic sweep)
        $wpdb->query($wpdb->prepare("DELETE FROM {$table_name} WHERE expires_at < %d", $now));
    }

    /**
     * Resolve the client IP address safely without trusting unverified forwarding headers
     *
     * @return string
     */
    public static function get_client_ip() {
        $remote_addr = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '127.0.0.1';

        // Check if trusted reverse proxy configuration is defined in wp-config.php
        $trusted_proxies = defined('SAHAND_TRUSTED_PROXIES') && is_array(SAHAND_TRUSTED_PROXIES) 
            ? SAHAND_TRUSTED_PROXIES 
            : array('127.0.0.1', '::1');

        $is_behind_trusted_proxy = in_array($remote_addr, $trusted_proxies, true);

        // If behind a trusted Cloudflare proxy and CF-Connecting-IP is set
        if ($is_behind_trusted_proxy && !empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            $cf_ip = sanitize_text_field(wp_unslash($_SERVER['HTTP_CF_CONNECTING_IP']));
            if (filter_var($cf_ip, FILTER_VALIDATE_IP)) {
                return $cf_ip;
            }
        }

        // If behind a verified trusted reverse proxy and X-Forwarded-For is set, take the leftmost valid public IP
        if ($is_behind_trusted_proxy && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $forwarded = sanitize_text_field(wp_unslash($_SERVER['HTTP_X_FORWARDED_FOR']));
            $ip_list = explode(',', $forwarded);
            foreach ($ip_list as $raw_ip) {
                $trimmed = trim($raw_ip);
                if (filter_var($trimmed, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $trimmed;
                }
            }
        }

        // Default to REMOTE_ADDR
        return filter_var($remote_addr, FILTER_VALIDATE_IP) ? $remote_addr : '127.0.0.1';
    }

    /**
     * Atomically check and increment rate limit for a given action and client
     *
     * @param string $action_key Category or action identifier (e.g. 'contact_form', 'ai_gateway')
     * @param int    $max_requests Maximum requests allowed in the window
     * @param int    $window_seconds Duration of the sliding window in seconds
     * @return array Array containing:
     *               'allowed'       => bool,
     *               'current'       => int,
     *               'max'           => int,
     *               'retry_after'   => int (seconds remaining until reset),
     *               'reset_at'      => int (timestamp)
     */
    public static function check_and_increment($action_key, $max_requests = 5, $window_seconds = 600) {
        global $wpdb;

        $client_ip = self::get_client_ip();
        // Hash IP with secret salt for GDPR compliance and privacy
        $salt = defined('AUTH_SALT') ? AUTH_SALT : 'sahand_fallback_salt_2026';
        $ip_hash = hash('sha256', $client_ip . '|' . $salt);

        $now = time();
        $bucket = (int) floor($now / max(1, $window_seconds));
        $expires_at = ($bucket + 1) * $window_seconds;
        $retry_after = max(1, $expires_at - $now);

        $table_name = $wpdb->prefix . self::TABLE_NAME;

        // Probabilistic garbage collection (1 in 100 requests)
        if (mt_rand(1, 100) === 42) {
            self::cleanup_expired();
        }

        // 1. Try atomic MySQL INSERT ... ON DUPLICATE KEY UPDATE
        // This eliminates race conditions on shared MySQL databases
        $query = $wpdb->prepare(
            "INSERT INTO {$table_name} (action_key, ip_hash, bucket, hits, expires_at)
             VALUES (%s, %s, %d, 1, %d)
             ON DUPLICATE KEY UPDATE hits = hits + 1",
            $action_key,
            $ip_hash,
            $bucket,
            $expires_at
        );

        $suppress = $wpdb->suppress_errors(true);
        $result = $wpdb->query($query);
        $wpdb->suppress_errors($suppress);

        if (false !== $result) {
            // Retrieve current hits for this bucket
            $current_hits = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT hits FROM {$table_name} WHERE action_key = %s AND ip_hash = %s AND bucket = %d",
                $action_key,
                $ip_hash,
                $bucket
            ));

            $allowed = ($current_hits <= (int) $max_requests);

            return array(
                'allowed'     => $allowed,
                'current'     => $current_hits,
                'max'         => (int) $max_requests,
                'retry_after' => $allowed ? 0 : $retry_after,
                'reset_at'    => $expires_at,
                'storage'     => 'mysql_atomic',
            );
        }

        // 2. Fallback to Transient storage if table is not yet provisioned
        $transient_key = 'sh_rt_' . substr(hash('sha256', "{$action_key}:{$ip_hash}:{$bucket}"), 0, 32);
        $current_hits = (int) get_transient($transient_key);
        $new_hits = $current_hits + 1;
        set_transient($transient_key, $new_hits, $retry_after);

        $allowed = ($new_hits <= (int) $max_requests);

        return array(
            'allowed'     => $allowed,
            'current'     => $new_hits,
            'max'         => (int) $max_requests,
            'retry_after' => $allowed ? 0 : $retry_after,
            'reset_at'    => $expires_at,
            'storage'     => 'transient_fallback',
        );
    }
}
