<?php
/**
 * Server-Side AI Inference Gateway (Gemini & Modular Provider Architecture)
 *
 * @package SahandCore
 */

if (!defined('ABSPATH')) {
    exit;
}

class Sahand_AI_Gateway {

    /**
     * REST namespace and route
     */
    const NAMESPACE = 'sahand/v1';
    const ROUTE = '/ai/generate';

    /**
     * Default Gemini model
     */
    const DEFAULT_MODEL = 'gemini-3.8-flash';

    /**
     * Maximum permitted characters in a single prompt
     */
    const MAX_PROMPT_LENGTH = 2000;

    /**
     * Initialize the AI gateway REST endpoints
     */
    public static function init() {
        add_action('rest_api_init', array(__CLASS__, 'register_routes'));
    }

    /**
     * Register REST API routes
     */
    public static function register_routes() {
        register_rest_route(self::NAMESPACE, self::ROUTE, array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array(__CLASS__, 'handle_generate_request'),
            'permission_callback' => '__return_true', // Public endpoint guarded by atomic rate limiting & honeypot
            'args'                => array(
                'prompt' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'maxLength'         => self::MAX_PROMPT_LENGTH,
                    'sanitize_callback' => 'sanitize_textarea_field',
                    'validate_callback' => array(__CLASS__, 'validate_prompt'),
                ),
                'task' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'default'           => 'general',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'language' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'default'           => 'en',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
    }

    /**
     * Validate prompt string
     *
     * @param mixed $value
     * @return bool
     */
    public static function validate_prompt($value) {
        if (!is_string($value)) {
            return false;
        }

        $length = mb_strlen(trim($value), 'UTF-8');
        return ($length >= 2 && $length <= self::MAX_PROMPT_LENGTH);
    }

    /**
     * Retrieve the server-side Gemini API key securely
     *
     * @return string
     */
    public static function get_api_key() {
        // 1. Check defined constant in wp-config.php (recommended for production)
        if (defined('SAHAND_GEMINI_API_KEY') && !empty(SAHAND_GEMINI_API_KEY)) {
            return (string) SAHAND_GEMINI_API_KEY;
        }

        // 2. Check environment variable
        $env_key = getenv('GEMINI_API_KEY');
        if (!empty($env_key)) {
            return (string) $env_key;
        }

        if (!empty($_ENV['GEMINI_API_KEY'])) {
            return (string) $_ENV['GEMINI_API_KEY'];
        }

        return '';
    }

    /**
     * Handle AI generation requests from the client
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public static function handle_generate_request($request) {
        // 1. Atomic Rate Limiting: 10 requests per 5 minutes per IP
        $rate_check = Sahand_Security::check_rate_limit('ai_gateway', 10, 300);
        if (!$rate_check['allowed']) {
            $response = new WP_REST_Response(array(
                'success'     => false,
                'error'       => 'Rate limit exceeded for AI inference. Please try again later.',
                'retry_after' => $rate_check['retry_after'],
            ), 429);
            $response->header('Retry-After', (string) $rate_check['retry_after']);
            return $response;
        }

        // 2. Retrieve server-configured API Key
        $api_key = self::get_api_key();
        if (empty($api_key)) {
            return new WP_REST_Response(array(
                'success' => false,
                'status'  => 'BLOCKED',
                'error'   => 'AI Inference Gateway is offline pending server configuration. Configure SAHAND_GEMINI_API_KEY in wp-config.php.',
            ), 503);
        }

        // 3. Extract and sanitize parameters
        $prompt   = trim((string) $request->get_param('prompt'));
        $task     = sanitize_text_field((string) $request->get_param('task'));
        $language = sanitize_text_field((string) $request->get_param('language'));

        // System instructions based on task and language context
        $system_instruction = "You are the AI engine powering the SAHAND Personal Technology Hub for Sahand Haghi. "
            . "Respond with technical precision, engineering rigor, and zero marketing fluff. "
            . "Context: Task is '{$task}', target language is '{$language}'.";

        $start_time = microtime(true);

        // 4. Dispatch request to Gemini REST API endpoint
        $endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/' . self::DEFAULT_MODEL . ':generateContent?key=' . rawurlencode($api_key);

        $payload = array(
            'contents' => array(
                array(
                    'parts' => array(
                        array('text' => $prompt),
                    ),
                ),
            ),
            'systemInstruction' => array(
                'parts' => array(
                    array('text' => $system_instruction),
                ),
            ),
        );

        $args = array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'User-Agent'   => 'aistudio-build',
            ),
            'body'    => wp_json_encode($payload),
            'timeout' => 15,
        );

        $http_response = wp_remote_post($endpoint, $args);
        $duration_ms = round((microtime(true) - $start_time) * 1000);

        if (is_wp_error($http_response)) {
            return new WP_REST_Response(array(
                'success' => false,
                'error'   => 'AI Gateway communication error: ' . esc_html($http_response->get_error_message()),
                'latency' => $duration_ms,
            ), 502);
        }

        $status_code = wp_remote_retrieve_response_code($http_response);
        $body = wp_remote_retrieve_body($http_response);
        $data = json_decode($body, true);

        if ($status_code !== 200) {
            $error_message = isset($data['error']['message']) ? $data['error']['message'] : 'Inference provider returned HTTP ' . $status_code;
            return new WP_REST_Response(array(
                'success' => false,
                'error'   => 'Upstream AI provider error: ' . esc_html($error_message),
                'latency' => $duration_ms,
            ), $status_code >= 400 && $status_code < 500 ? $status_code : 502);
        }

        // Extract generated text from candidate response parts
        $candidate_text = '';
        if (isset($data['candidates'][0]['content']['parts'])) {
            foreach ($data['candidates'][0]['content']['parts'] as $part) {
                if (isset($part['text'])) {
                    $candidate_text .= $part['text'];
                }
            }
        }

        return new WP_REST_Response(array(
            'success'    => true,
            'text'       => $candidate_text,
            'model'      => self::DEFAULT_MODEL,
            'latency_ms' => $duration_ms,
            'status'     => 'VERIFIED',
        ), 200);
    }
}
