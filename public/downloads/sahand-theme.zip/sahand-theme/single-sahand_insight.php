<?php
/**
 * Single Template for sahand_insight CPT (Research & Technical Insights)
 *
 * @package SahandTheme
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
$current_lang = function_exists('sahand_get_current_lang') ? sahand_get_current_lang() : 'fa';
?>

<main id="primary" class="site-main" style="background-color: var(--color-canvas); color: var(--color-text-primary); padding-block: 4rem 6rem;">
  <div class="sahand-container">
    <?php
    while (have_posts()) : the_post();
        $post_id       = get_the_ID();
        $reading_time  = get_post_meta($post_id, '_sahand_insight_reading_time', true) ?: '6';
        $difficulty    = get_post_meta($post_id, '_sahand_insight_difficulty', true) ?: 'intermediate';
        $canonical_url = get_post_meta($post_id, '_sahand_insight_canonical_url', true);
        $peer_reviewed = get_post_meta($post_id, '_sahand_insight_peer_reviewed', true) ?: 'no';
        $key_takeaway  = get_post_meta($post_id, '_sahand_insight_key_takeaway', true);
        ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?> style="max-width: 820px; margin-inline: auto;">
          
          <nav aria-label="<?php esc_attr_e('Breadcrumbs', 'sahand-theme'); ?>" style="margin-bottom: 2rem;">
            <a href="<?php echo esc_url(home_url('/' . $current_lang . '/insights/')); ?>" style="color: var(--color-accent); text-decoration: none; font-size: 0.875rem;">
              ← <?php esc_html_e('Back to Insights', 'sahand-theme'); ?>
            </a>
          </nav>

          <header style="margin-bottom: 3rem; border-bottom: 1px solid var(--color-border-subtle); padding-bottom: 2rem;">
            <div style="display: flex; gap: 0.75rem; align-items: center; margin-bottom: 1rem; flex-wrap: wrap;">
              <span class="badge badge-stable" style="text-transform: uppercase;">
                DEPTH: <?php echo esc_html($difficulty); ?>
              </span>
              <span class="badge badge-tech font-mono" style="font-size: 0.8125rem;">
                ⏱ <?php echo esc_html($reading_time); ?> MIN READ
              </span>
              <?php if ('yes' === $peer_reviewed) : ?>
                <span class="badge badge-stable" style="font-size: 0.8125rem;">
                  ✓ PEER REVIEWED
                </span>
              <?php endif; ?>
            </div>

            <h1 style="font-size: clamp(2.25rem, 5vw, 3.25rem); font-weight: 800; line-height: 1.25;">
              <?php the_title(); ?>
            </h1>

            <div class="font-mono" style="font-size: 0.875rem; color: var(--color-text-tertiary); margin-top: 1rem;">
              <span><?php echo get_the_date('F j, Y'); ?></span> · <span>Sahand Haghi</span>
            </div>
          </header>

          <?php if ($key_takeaway) : ?>
            <div style="background: rgba(2, 132, 199, 0.05); border-left: 4px solid var(--color-accent); border-radius: 0 var(--radius-md) var(--radius-md) 0; padding: 1.5rem; margin-bottom: 2.5rem;">
              <div class="font-mono" style="font-size: 0.75rem; color: var(--color-accent); font-weight: 700; margin-bottom: 0.5rem; text-transform: uppercase;">
                <?php esc_html_e('Architectural Thesis / Core Takeaway:', 'sahand-theme'); ?>
              </div>
              <p style="font-size: 1.0625rem; line-height: 1.7; color: var(--color-text-primary); margin: 0; font-weight: 500;">
                <?php echo nl2br(esc_html($key_takeaway)); ?>
              </p>
            </div>
          <?php endif; ?>

          <div class="entry-content" style="font-size: 1.125rem; line-height: 1.85; color: var(--color-text-secondary);">
            <?php the_content(); ?>
          </div>

          <?php if ($canonical_url) : ?>
            <footer style="margin-top: 3.5rem; pt-4; border-top: 1px solid var(--color-border-subtle); font-size: 0.875rem; color: var(--color-text-tertiary);">
              <span>Syndication Reference:</span>
              <a href="<?php echo esc_url($canonical_url); ?>" target="_blank" rel="noopener noreferrer" style="color: var(--color-accent); margin-left: 0.5rem;">
                <?php echo esc_url($canonical_url); ?> ↗
              </a>
            </footer>
          <?php endif; ?>

        </article>
        <?php
    endwhile;
    ?>
  </div>
</main>

<?php
get_footer();
