<?php
/**
 * The template for displaying 404 pages (Not Found)
 *
 * @package SahandTheme
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
$current_lang = function_exists('sahand_get_current_lang') ? sahand_get_current_lang() : 'fa';
?>

<main id="primary" class="site-main" style="background-color: var(--color-canvas); color: var(--color-text-primary); min-height: 75vh; display: flex; align-items: center; padding-block: 4rem 6rem;">
  <div class="sahand-container" style="max-width: 680px; text-align: center;">
    
    <div class="badge badge-tech" style="margin-bottom: 1.5rem; display: inline-block;">
      <span>HTTP 404 // RESOURCE ROUTING EXCEPTION</span>
    </div>

    <h1 style="font-size: clamp(3.5rem, 8vw, 6rem); font-weight: 800; line-height: 1; letter-spacing: -0.04em; margin-bottom: 1rem; color: var(--color-accent);">
      404
    </h1>

    <h2 style="font-size: clamp(1.5rem, 3vw, 2rem); font-weight: 700; margin-bottom: 1.25rem;">
      <?php
      if ($current_lang === 'fa') {
          echo esc_html('مسیریابی ناموفق — صفحه مورد نظر یافت نشد');
      } elseif ($current_lang === 'tr') {
          echo esc_html('Kaynak Bulunamadı — 404 Yönlendirme Hatası');
      } else {
          echo esc_html('Route Not Found — 404 Exception');
      }
      ?>
    </h2>

    <p style="font-size: 1.0625rem; color: var(--color-text-secondary); line-height: 1.7; margin-bottom: 2.5rem;">
      <?php
      if ($current_lang === 'fa') {
          echo esc_html('نشانی اینترنتی فراخوانی‌شده در ساختار پلتفرم سهند موجود نبوده یا به نشانی دیگری منتقل شده است. لطفاً از پیوندهای زیر جهت ناوبری استفاده فرمایید.');
      } elseif ($current_lang === 'tr') {
          echo esc_html('Talep edilen URL adresi SAHAND sisteminde bulunamadı veya taşınmış olabilir. Lütfen ana sayfaya veya ilgili bölümlere dönün.');
      } else {
          echo esc_html('The requested endpoint or resource does not exist in the SAHAND architecture. It may have been deprecated or moved.');
      }
      ?>
    </p>

    <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
      <a href="<?php echo esc_url(home_url('/' . $current_lang . '/')); ?>" class="badge badge-stable" style="text-decoration: none; padding: 0.85rem 2rem; font-size: 0.9375rem; font-weight: 700; border-radius: var(--radius-md);">
        ← <?php
        if ($current_lang === 'fa') {
            echo esc_html('بازگشت به صفحه اصلی');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Ana Sayfaya Dön');
        } else {
            echo esc_html('Return to Home');
        }
        ?>
      </a>

      <a href="<?php echo esc_url(home_url('/' . $current_lang . '/projects/')); ?>" class="badge badge-tech" style="text-decoration: none; padding: 0.85rem 1.75rem; font-size: 0.9375rem; font-weight: 600; border-radius: var(--radius-md);">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('پروژه‌های مهندسی');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Mühendislik Projeleri');
        } else {
            echo esc_html('Engineering Projects');
        }
        ?>
      </a>
    </div>

  </div>
</main>

<?php
get_footer();
