<?php
/**
 * Template Name: Contact & Secure Communication
 *
 * @package SahandTheme
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
$current_lang = function_exists('sahand_get_current_lang') ? sahand_get_current_lang() : 'fa';
$contact_nonce = wp_create_nonce('sahand_contact_nonce');
?>

<main id="primary" class="site-main" style="background-color: var(--color-canvas); color: var(--color-text-primary); min-height: 80vh; padding-block: 4rem 6rem;">
  <div class="sahand-container" style="max-width: 800px;">
    
    <header style="margin-bottom: 3.5rem; border-bottom: 1px solid var(--color-border-subtle); padding-bottom: 2rem; text-align: center;">
      <div class="badge badge-stable" style="margin-bottom: 1rem; display: inline-block;">
        <span>INGRESS // ENCRYPTED & RATE-LIMITED INBOX</span>
      </div>
      <h1 style="font-size: clamp(2rem, 4vw, 3rem); font-weight: 800; letter-spacing: -0.02em;">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('ارتباط مستقیم و همکاری‌های فنی');
        } elseif ($current_lang === 'tr') {
            echo esc_html('İletişim ve Mühendislik İş Birlikleri');
        } else {
            echo esc_html('Direct Communication & Engineering Inquiries');
        }
        ?>
      </h1>
      <p style="font-size: 1.125rem; color: var(--color-text-secondary); max-width: 600px; margin: 0.75rem auto 0; line-height: 1.7;">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('جهت مشاوره فنی، طراحی سیستم‌های نرم‌افزاری یا همکاری در پروژه‌های مقیاس‌پذیر، پیام خود را مستقیماً ارسال فرمایید.');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Yazılım sistemleri mimarisi, teknik danışmanlık veya ölçeklenebilir projeler için doğrudan iletişime geçebilirsiniz.');
        } else {
            echo esc_html('For systems architecture consulting, algorithm development, or engineering collaborations, send a direct verified message.');
        }
        ?>
      </p>
    </header>

    <div class="sahand-card" style="box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);">
      
      <!-- Live Server Response Alert Box -->
      <div id="contact-alert" role="alert" style="display: none; padding: 1rem 1.25rem; border-radius: var(--radius-md); margin-bottom: 1.5rem; font-size: 0.9375rem; line-height: 1.5;"></div>

      <form id="sahand-contact-form" method="post" action="<?php echo esc_url(rest_url('sahand/v1/contact')); ?>" novalidate>
        
        <!-- Security Nonce & Honeypot Fields -->
        <input type="hidden" name="_wpnonce" id="contact-nonce" value="<?php echo esc_attr($contact_nonce); ?>">
        <div style="position: absolute; left: -9999px; top: -9999px;" aria-hidden="true">
          <label for="contact-hp">Leave this field blank</label>
          <input type="text" name="_sahand_hp" id="contact-hp" tabindex="-1" autocomplete="off">
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; margin-bottom: 1.5rem;">
          <div>
            <label for="contact-name" style="display: block; font-weight: 600; margin-bottom: 0.5rem; font-size: 0.875rem;">
              <?php esc_html_e('Full Name / Organization:', 'sahand-theme'); ?> *
            </label>
            <input type="text" name="name" id="contact-name" required maxlength="100" style="width: 100%; padding: 0.75rem 1rem; border: 1px solid var(--color-border-subtle); border-radius: var(--radius-md); font-size: 1rem;" placeholder="<?php esc_attr_e('e.g. Sahand Haghi', 'sahand-theme'); ?>">
          </div>

          <div>
            <label for="contact-email" style="display: block; font-weight: 600; margin-bottom: 0.5rem; font-size: 0.875rem;">
              <?php esc_html_e('Email Address:', 'sahand-theme'); ?> *
            </label>
            <input type="email" name="email" id="contact-email" required maxlength="120" style="width: 100%; padding: 0.75rem 1rem; border: 1px solid var(--color-border-subtle); border-radius: var(--radius-md); font-size: 1rem;" placeholder="<?php esc_attr_e('name@domain.com', 'sahand-theme'); ?>">
          </div>
        </div>

        <div style="margin-bottom: 2rem;">
          <label for="contact-message" style="display: block; font-weight: 600; margin-bottom: 0.5rem; font-size: 0.875rem;">
            <?php esc_html_e('Engineering Specifications / Inquiry Message:', 'sahand-theme'); ?> *
          </label>
          <textarea name="message" id="contact-message" rows="5" required minlength="5" maxlength="5000" style="width: 100%; padding: 0.75rem 1rem; border: 1px solid var(--color-border-subtle); border-radius: var(--radius-md); font-size: 1rem; resize: vertical;" placeholder="<?php esc_attr_e('Provide technical scope, objectives, or questions...', 'sahand-theme'); ?>"></textarea>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
          <span class="font-mono" style="font-size: 0.75rem; color: var(--color-text-tertiary);">
            🔒 SSL ENCRYPTED · ATOMIC RATE-LIMITED
          </span>

          <button type="submit" id="contact-submit-btn" class="badge badge-stable" style="cursor: pointer; padding: 0.85rem 2rem; font-size: 1rem; border: none; font-weight: 700; border-radius: var(--radius-md);">
            <?php esc_html_e('Send Message', 'sahand-theme'); ?> →
          </button>
        </div>

      </form>
    </div>

    <!-- Official Communication Channels -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1.5rem; margin-top: 3rem;">
      <div class="sahand-card" style="text-align: center;">
        <span class="font-mono" style="font-size: 0.75rem; color: var(--color-text-tertiary);">VERIFIED EMAIL</span>
        <div style="font-weight: 700; margin-top: 0.5rem; font-size: 0.9375rem;">
          <a href="mailto:haghisahnd@gmail.com" style="color: var(--color-accent); text-decoration: none;">haghisahnd@gmail.com</a>
        </div>
      </div>
      <div class="sahand-card" style="text-align: center;">
        <span class="font-mono" style="font-size: 0.75rem; color: var(--color-text-tertiary);">SOURCE CODE</span>
        <div style="font-weight: 700; margin-top: 0.5rem; font-size: 0.9375rem;">
          <a href="https://github.com/haghisahand-ai" target="_blank" rel="noopener noreferrer" style="color: var(--color-text-primary); text-decoration: none;">github.com/haghisahand-ai</a>
        </div>
      </div>
      <div class="sahand-card" style="text-align: center;">
        <span class="font-mono" style="font-size: 0.75rem; color: var(--color-text-tertiary);">PRODUCTION DOMAIN</span>
        <div style="font-weight: 700; margin-top: 0.5rem; font-size: 0.9375rem;">
          <span style="color: var(--color-accent);">sahandhaghi.site</span>
        </div>
      </div>
    </div>

  </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const form = document.getElementById('sahand-contact-form');
  const alertBox = document.getElementById('contact-alert');
  const submitBtn = document.getElementById('contact-submit-btn');

  if (!form) return;

  form.addEventListener('submit', async function(e) {
    e.preventDefault();

    const name = document.getElementById('contact-name').value.trim();
    const email = document.getElementById('contact-email').value.trim();
    const message = document.getElementById('contact-message').value.trim();
    const nonce = document.getElementById('contact-nonce').value;
    const hp = document.getElementById('contact-hp').value;

    // Client-side quick check
    if (!name || !email || !message || message.length < 5) {
      showAlert('error', '<?php echo esc_js(__('Please fill out all required fields with a message of at least 5 characters.', 'sahand-theme')); ?>');
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = '<?php echo esc_js(__('Transmitting...', 'sahand-theme')); ?>';

    try {
      const response = await fetch('<?php echo esc_url(rest_url('sahand/v1/contact')); ?>', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': nonce
        },
        body: JSON.stringify({
          name: name,
          email: email,
          message: message,
          _wpnonce: nonce,
          _sahand_hp: hp
        })
      });

      const data = await response.json();

      if (response.ok && data.success) {
        showAlert('success', data.message || '<?php echo esc_js(__('Your message has been delivered.', 'sahand-theme')); ?>');
        form.reset();
      } else {
        const errorMsg = data.message || ('<?php echo esc_js(__('Submission failed with status', 'sahand-theme')); ?> ' + response.status);
        showAlert('error', errorMsg);
      }
    } catch (err) {
      showAlert('error', '<?php echo esc_js(__('Network communication error. Please check your connection or contact via direct email.', 'sahand-theme')); ?>');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = '<?php echo esc_js(__('Send Message', 'sahand-theme')); ?> →';
    }
  });

  function showAlert(type, message) {
    alertBox.style.display = 'block';
    if (type === 'success') {
      alertBox.style.background = 'rgba(16, 185, 129, 0.1)';
      alertBox.style.border = '1px solid #10B981';
      alertBox.style.color = '#065F46';
    } else {
      alertBox.style.background = 'rgba(239, 68, 68, 0.1)';
      alertBox.style.border = '1px solid #EF4444';
      alertBox.style.color = '#991B1B';
    }
    alertBox.textContent = message;
    alertBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
});
</script>

<?php
get_footer();
