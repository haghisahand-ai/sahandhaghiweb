<?php
/**
 * Single Template for sahand_ai_tool CPT (AI Lab Models & Tools)
 *
 * @package SahandTheme
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
$current_lang = function_exists('sahand_get_current_lang') ? sahand_get_current_lang() : 'fa';
?>

<main id="primary" class="site-main" style="background-color: var(--color-canvas); color: var(--color-text-primary); padding-block: 4rem 6rem;">
  <div class="sahand-container">
    <?php
    while (have_posts()) : the_post();
        $post_id    = get_the_ID();
        $model      = get_post_meta($post_id, '_sahand_ai_model', true) ?: 'gemini-3.8-flash';
        $task       = get_post_meta($post_id, '_sahand_ai_task', true) ?: 'Reasoning & Inference';
        $latency    = get_post_meta($post_id, '_sahand_ai_latency', true) ?: '35ms';
        $status     = get_post_meta($post_id, '_sahand_ai_status', true) ?: 'active';
        $endpoint   = get_post_meta($post_id, '_sahand_ai_endpoint', true);
        $parameters = get_post_meta($post_id, '_sahand_ai_parameters', true);
        $demo_url   = get_post_meta($post_id, '_sahand_ai_demo_url', true);
        ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?> style="max-width: 860px; margin-inline: auto;">
          
          <nav aria-label="<?php esc_attr_e('Breadcrumbs', 'sahand-theme'); ?>" style="margin-bottom: 2rem;">
            <a href="<?php echo esc_url(home_url('/' . $current_lang . '/ai-lab/')); ?>" style="color: var(--color-accent); text-decoration: none; font-size: 0.875rem;">
              ← <?php esc_html_e('Back to AI Lab', 'sahand-theme'); ?>
            </a>
          </nav>

          <header style="margin-bottom: 3rem; border-bottom: 1px solid var(--color-border-subtle); padding-bottom: 2rem;">
            <div style="display: flex; gap: 0.75rem; align-items: center; margin-bottom: 1rem; flex-wrap: wrap;">
              <span class="badge badge-stable" style="text-transform: uppercase;">
                <?php echo esc_html($status); ?>
              </span>
              <span class="badge badge-tech font-mono" style="font-size: 0.8125rem;">
                MODEL: <?php echo esc_html($model); ?>
              </span>
              <?php if ($latency) : ?>
                <span class="font-mono" style="font-size: 0.8125rem; color: var(--color-text-tertiary);">
                  ⚡ <?php echo esc_html($latency); ?>
                </span>
              <?php endif; ?>
            </div>

            <h1 style="font-size: clamp(2.25rem, 5vw, 3.25rem); font-weight: 800; line-height: 1.2;">
              <?php the_title(); ?>
            </h1>

            <p style="font-size: 1.125rem; color: var(--color-text-secondary); margin-top: 1rem;">
              <?php echo esc_html($task); ?>
            </p>

            <?php if ($demo_url) : ?>
              <div style="margin-top: 1.5rem;">
                <a href="<?php echo esc_url($demo_url); ?>" target="_blank" rel="noopener noreferrer" class="badge badge-stable" style="text-decoration: none; padding: 0.75rem 1.75rem; font-size: 0.9375rem; font-weight: 700; display: inline-flex; align-items: center; gap: 0.5rem;">
                  <span>Interactive Playground / Sandbox ↗</span>
                </a>
              </div>
            <?php endif; ?>
          </header>

          <!-- Architectural Specs Grid -->
          <section style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1rem; margin-bottom: 3rem;">
            <div class="sahand-card">
              <span class="font-mono" style="font-size: 0.75rem; color: var(--color-text-tertiary);">ARCHITECTURE</span>
              <div style="font-weight: 700; margin-top: 0.25rem; font-size: 0.9375rem;"><?php echo esc_html($model); ?></div>
            </div>
            <div class="sahand-card">
              <span class="font-mono" style="font-size: 0.75rem; color: var(--color-text-tertiary);">MEASURED LATENCY</span>
              <div style="font-weight: 700; margin-top: 0.25rem; font-size: 0.9375rem;"><?php echo esc_html($latency); ?></div>
            </div>
            <?php if ($parameters) : ?>
              <div class="sahand-card">
                <span class="font-mono" style="font-size: 0.75rem; color: var(--color-text-tertiary);">CONTEXT / PARAMS</span>
                <div style="font-weight: 700; margin-top: 0.25rem; font-size: 0.9375rem;"><?php echo esc_html($parameters); ?></div>
              </div>
            <?php endif; ?>
            <?php if ($endpoint) : ?>
              <div class="sahand-card">
                <span class="font-mono" style="font-size: 0.75rem; color: var(--color-text-tertiary);">REST INGRESS</span>
                <div class="font-mono" style="font-weight: 600; margin-top: 0.25rem; font-size: 0.8125rem; color: var(--color-accent);"><?php echo esc_html($endpoint); ?></div>
              </div>
            <?php endif; ?>
          </section>

          <div class="entry-content" style="font-size: 1.125rem; line-height: 1.8; color: var(--color-text-secondary);">
            <?php the_content(); ?>
          </div>

        </article>
        <?php
    endwhile;
    ?>
  </div>
</main>

<?php
get_footer();
