<?php
/**
 * Template Name: About Sahand Haghi & Philosophy
 *
 * @package SahandTheme
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
$current_lang = function_exists('sahand_get_current_lang') ? sahand_get_current_lang() : 'fa';
?>

<main id="primary" class="site-main" style="background-color: var(--color-canvas); color: var(--color-text-primary); min-height: 80vh; padding-block: 4rem 6rem;">
  <div class="sahand-container" style="max-width: 900px;">
    
    <header style="margin-bottom: 3.5rem; border-bottom: 1px solid var(--color-border-subtle); padding-bottom: 2rem;">
      <div class="badge badge-stable" style="margin-bottom: 1rem; display: inline-block;">
        <span>IDENTITY // BUILDER · ARCHITECT · INDEPENDENT DEVELOPER</span>
      </div>
      <h1 style="font-size: clamp(2.25rem, 4.5vw, 3.25rem); font-weight: 800; letter-spacing: -0.02em;">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('سهند حقی — معمار نرم‌افزار، توسعه‌دهنده و پژوهشگر');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Sahand Haghi — Yazılım Mimarı, Geliştirici ve Araştırmacı');
        } else {
            echo esc_html('Sahand Haghi — Software Architect, Builder & Researcher');
        }
        ?>
      </h1>
      <p style="font-size: 1.25rem; color: var(--color-text-secondary); margin-top: 1rem; line-height: 1.7; font-weight: 400;">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('فراتر از فناوری. ساخت آنچه در راه است.');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Teknolojinin Ötesinde. Geleceği İnşa Etmek.');
        } else {
            echo esc_html('Beyond Technology. Building What\'s Next.');
        }
        ?>
      </p>
    </header>

    <div style="font-size: 1.125rem; line-height: 1.8; color: var(--color-text-secondary); display: flex; flex-direction: column; gap: 2rem;">
      
      <p>
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('نام سهند برگرفته از قله سرفراز سهند در آذربایجان، نماد استواری، پایداری و بلندنظری مهندسی است. این پلتفرم فضایی برای توسعه و اشتراک‌گذاری سیستم‌های نرم‌افزاری پیچیده، موتورهای معاملاتی، ابزارهای هوش مصنوعی و محصولات دیجیتال مستقل است.');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Sahand adı, Azerbaycan\'ın görkemli Sahand Dağı\'ndan ilham alarak kararlılık, dayanıklılık ve mühendislik vizyonunu simgeler. Bu platform; yüksek ölçeklenebilir yazılım mimarileri, yapay zeka sistemleri ve bağımsız dijital ürünler geliştirmeye adanmıştır.');
        } else {
            echo esc_html('Inspired by the geological permanence of Mount Sahand in Azerbaijan, the brand embodies resilience, architectural precision, and uncompromising engineering discipline. SAHAND is an independent personal technology hub dedicated to scalable distributed software, sovereign AI gateways, and deterministic algorithmic systems.');
        }
        ?>
      </p>

      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1.5rem; margin-block: 1rem;">
        <div class="sahand-card">
          <div class="badge badge-tech font-mono" style="margin-bottom: 0.75rem;">FOCUS 01</div>
          <h3 style="font-weight: 700; margin-bottom: 0.5rem;"><?php esc_html_e('Financial Markets & Order Flow', 'sahand-theme'); ?></h3>
          <p style="font-size: 0.875rem; color: var(--color-text-secondary); margin: 0;">
            <?php esc_html_e('MicroMap price action, London/New York session windows, and high-precision execution algorithms.', 'sahand-theme'); ?>
          </p>
        </div>

        <div class="sahand-card">
          <div class="badge badge-tech font-mono" style="margin-bottom: 0.75rem;">FOCUS 02</div>
          <h3 style="font-weight: 700; margin-bottom: 0.5rem;"><?php esc_html_e('Decoupled Web Architecture', 'sahand-theme'); ?></h3>
          <p style="font-size: 0.875rem; color: var(--color-text-secondary); margin: 0;">
            <?php esc_html_e('Custom high-performance WordPress themes and plugins built for speed, defense-in-depth, and standard hosting compatibility.', 'sahand-theme'); ?>
          </p>
        </div>

        <div class="sahand-card">
          <div class="badge badge-tech font-mono" style="margin-bottom: 0.75rem;">FOCUS 03</div>
          <h3 style="font-weight: 700; margin-bottom: 0.5rem;"><?php esc_html_e('Sovereign AI Systems', 'sahand-theme'); ?></h3>
          <p style="font-size: 0.875rem; color: var(--color-text-secondary); margin: 0;">
            <?php esc_html_e('Modular server-side gateways utilizing Gemini 3.8 and local model pipelines with zero client credential exposure.', 'sahand-theme'); ?>
          </p>
        </div>
      </div>

      <div style="padding: 1.5rem; background: rgba(2, 132, 199, 0.05); border: 1px solid rgba(2, 132, 199, 0.2); border-radius: var(--radius-md);">
        <h3 style="font-size: 1.125rem; font-weight: 700; color: var(--color-accent); margin-bottom: 0.5rem;">
          <?php esc_html_e('Engineering Manifesto & Code of Practice', 'sahand-theme'); ?>
        </h3>
        <p style="margin: 0; font-size: 0.9375rem; line-height: 1.7;">
          <?php esc_html_e('We prioritize verified tests over assumptions, deterministic logic over unmeasured magic, native internationalization over machine translation, and robust defense-in-depth security over convenience.', 'sahand-theme'); ?>
        </p>
      </div>

    </div>

  </div>
</main>

<?php
get_footer();
