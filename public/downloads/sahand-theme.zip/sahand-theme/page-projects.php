<?php
/**
 * Template Name: Projects Archive & Directory
 *
 * @package SahandTheme
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
$current_lang = function_exists('sahand_get_current_lang') ? sahand_get_current_lang() : 'fa';
?>

<main id="primary" class="site-main" style="background-color: var(--color-canvas); color: var(--color-text-primary); min-height: 80vh; padding-block: 4rem 6rem;">
  <div class="sahand-container">
    
    <!-- Section Header -->
    <header style="margin-bottom: 3.5rem; border-bottom: 1px solid var(--color-border-subtle); padding-bottom: 2rem;">
      <div class="badge badge-stable" style="margin-bottom: 1rem; display: inline-block;">
        <span>SYS.ARCH // CASE STUDIES</span>
      </div>
      <h1 style="font-size: clamp(2rem, 4vw, 3rem); font-weight: 800; letter-spacing: -0.02em;">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('پروژه‌ها و مطالعات موردی مهندسی');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Mühendislik Projeleri ve Vaka Çalışmaları');
        } else {
            echo esc_html('Engineering Projects & Architectural Case Studies');
        }
        ?>
      </h1>
      <p style="font-size: 1.125rem; color: var(--color-text-secondary); max-width: 700px; margin-top: 0.75rem; line-height: 1.7;">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('معماری‌های فنی، سیستم‌های الگوریتمی، و زیرساخت‌های مقیاس‌پذیر همراه با جزئیات فنی و چالش‌های حل‌شده.');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Ölçeklenebilir sistemler, algoritmik motorlar ve çözülen teknik zorluklar hakkında ayrıntılı vaka analizleri.');
        } else {
            echo esc_html('In-depth technical case studies on high-throughput order routing, sovereign AI gateways, and multi-tier infrastructure.');
        }
        ?>
      </p>
    </header>

    <!-- Projects Grid -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 2rem;">
      <?php
      $projects_query = new WP_Query(array(
          'post_type'      => 'sahand_project',
          'post_status'    => 'publish',
          'posts_per_page' => 20,
          'orderby'        => 'date',
          'order'          => 'DESC',
      ));

      if ($projects_query->have_posts()) :
          while ($projects_query->have_posts()) : $projects_query->the_post();
              $post_id   = get_the_ID();
              $status    = get_post_meta($post_id, '_sahand_project_status', true) ?: 'production';
              $timeline  = get_post_meta($post_id, '_sahand_project_timeline', true);
              $github    = get_post_meta($post_id, '_sahand_project_github', true);
              $demo_url  = get_post_meta($post_id, '_sahand_project_demo_url', true);
              $problem   = get_post_meta($post_id, '_sahand_project_problem', true);
              $solution  = get_post_meta($post_id, '_sahand_project_solution', true);
              ?>
              <article id="post-<?php the_ID(); ?>" <?php post_class('sahand-card'); ?> style="display: flex; flex-direction: column; justify-content: space-between;">
                <div>
                  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                    <span class="badge badge-stable" style="text-transform: uppercase; font-size: 0.75rem;">
                      <?php echo esc_html($status); ?>
                    </span>
                    <?php if ($timeline) : ?>
                      <span class="font-mono" style="font-size: 0.75rem; color: var(--color-text-tertiary);">
                        <?php echo esc_html($timeline); ?>
                      </span>
                    <?php endif; ?>
                  </div>

                  <h2 style="font-size: 1.375rem; font-weight: 700; margin-bottom: 0.75rem;">
                    <a href="<?php the_permalink(); ?>" style="color: inherit; text-decoration: none;">
                      <?php the_title(); ?>
                    </a>
                  </h2>

                  <div style="font-size: 0.9375rem; color: var(--color-text-secondary); line-height: 1.6; margin-bottom: 1.25rem;">
                    <?php the_excerpt(); ?>
                  </div>

                  <?php if ($problem) : ?>
                    <div style="margin-bottom: 1rem; padding: 0.85rem; background: rgba(0, 0, 0, 0.02); border-left: 3px solid var(--color-accent); font-size: 0.875rem;">
                      <strong style="color: var(--color-text-primary);"><?php esc_html_e('Challenge:', 'sahand-theme'); ?></strong>
                      <p style="margin: 0.25rem 0 0; color: var(--color-text-secondary);"><?php echo esc_html(wp_trim_words($problem, 20)); ?></p>
                    </div>
                  <?php endif; ?>
                </div>

                <div style="display: flex; flex-wrap: wrap; gap: 0.75rem; margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid var(--color-border-subtle);">
                  <a href="<?php the_permalink(); ?>" class="badge badge-tech" style="text-decoration: none;">
                    <?php esc_html_e('Architecture Deep-Dive', 'sahand-theme'); ?> →
                  </a>
                  <?php if ($github) : ?>
                    <a href="<?php echo esc_url($github); ?>" target="_blank" rel="noopener noreferrer" class="badge" style="text-decoration: none; background: rgba(0,0,0,0.04); color: var(--color-text-primary);">
                      GitHub
                    </a>
                  <?php endif; ?>
                  <?php if ($demo_url) : ?>
                    <a href="<?php echo esc_url($demo_url); ?>" target="_blank" rel="noopener noreferrer" class="badge" style="text-decoration: none; background: rgba(2, 132, 199, 0.1); color: var(--color-accent);">
                      <?php esc_html_e('Demo / Staging', 'sahand-theme'); ?>
                    </a>
                  <?php endif; ?>
                </div>
              </article>
              <?php
          endwhile;
          wp_reset_postdata();
      else :
          ?>
          <div class="sahand-card" style="grid-column: 1 / -1; text-align: center; padding: 3rem;">
            <p style="color: var(--color-text-secondary); font-size: 1.125rem;">
              <?php esc_html_e('Engineering project case studies are being published. Check back soon.', 'sahand-theme'); ?>
            </p>
          </div>
          <?php
      endif;
      ?>
    </div>

  </div>
</main>

<?php
get_footer();
