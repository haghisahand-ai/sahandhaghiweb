<?php
/**
 * Single Template for sahand_project CPT
 *
 * @package SahandTheme
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
$current_lang = function_exists('sahand_get_current_lang') ? sahand_get_current_lang() : 'fa';
?>

<main id="primary" class="site-main" style="background-color: var(--color-canvas); color: var(--color-text-primary); padding-block: 4rem 6rem;">
  <div class="sahand-container">
    <?php
    while (have_posts()) : the_post();
        $post_id   = get_the_ID();
        $status    = get_post_meta($post_id, '_sahand_project_status', true) ?: 'production';
        $timeline  = get_post_meta($post_id, '_sahand_project_timeline', true);
        $github    = get_post_meta($post_id, '_sahand_project_github', true);
        $demo_url  = get_post_meta($post_id, '_sahand_project_demo_url', true);
        $problem   = get_post_meta($post_id, '_sahand_project_problem', true);
        $solution  = get_post_meta($post_id, '_sahand_project_solution', true);
        ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?> style="max-width: 860px; margin-inline: auto;">
          
          <nav aria-label="<?php esc_attr_e('Breadcrumbs', 'sahand-theme'); ?>" style="margin-bottom: 2rem;">
            <a href="<?php echo esc_url(home_url('/' . $current_lang . '/projects/')); ?>" style="color: var(--color-accent); text-decoration: none; font-size: 0.875rem;">
              ← <?php esc_html_e('Back to Projects', 'sahand-theme'); ?>
            </a>
          </nav>

          <header style="margin-bottom: 3rem; border-bottom: 1px solid var(--color-border-subtle); padding-bottom: 2rem;">
            <div style="display: flex; gap: 0.75rem; align-items: center; margin-bottom: 1rem;">
              <span class="badge badge-stable" style="text-transform: uppercase;">
                <?php echo esc_html($status); ?>
              </span>
              <?php if ($timeline) : ?>
                <span class="font-mono" style="font-size: 0.8125rem; color: var(--color-text-tertiary);">
                  <?php echo esc_html($timeline); ?>
                </span>
              <?php endif; ?>
            </div>

            <h1 style="font-size: clamp(2.25rem, 5vw, 3.25rem); font-weight: 800; line-height: 1.2;">
              <?php the_title(); ?>
            </h1>

            <div style="display: flex; flex-wrap: wrap; gap: 1rem; margin-top: 1.5rem;">
              <?php if ($github) : ?>
                <a href="<?php echo esc_url($github); ?>" target="_blank" rel="noopener noreferrer" class="badge badge-tech" style="text-decoration: none; padding: 0.6rem 1.2rem;">
                  GitHub Repository ↗
                </a>
              <?php endif; ?>
              <?php if ($demo_url) : ?>
                <a href="<?php echo esc_url($demo_url); ?>" target="_blank" rel="noopener noreferrer" class="badge badge-stable" style="text-decoration: none; padding: 0.6rem 1.2rem;">
                  Live Deployment / Staging ↗
                </a>
              <?php endif; ?>
            </div>
          </header>

          <?php if ($problem || $solution) : ?>
            <section style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; margin-bottom: 3rem;">
              <?php if ($problem) : ?>
                <div style="background: rgba(239, 68, 68, 0.04); border: 1px solid rgba(239, 68, 68, 0.2); border-radius: var(--radius-md); padding: 1.5rem;">
                  <h2 style="font-size: 1.125rem; font-weight: 700; color: #DC2626; margin-bottom: 0.75rem;">
                    <?php esc_html_e('Problem & Technical Challenge', 'sahand-theme'); ?>
                  </h2>
                  <p style="font-size: 0.9375rem; line-height: 1.7; color: var(--color-text-secondary); margin: 0;">
                    <?php echo nl2br(esc_html($problem)); ?>
                  </p>
                </div>
              <?php endif; ?>

              <?php if ($solution) : ?>
                <div style="background: rgba(2, 132, 199, 0.04); border: 1px solid rgba(2, 132, 199, 0.2); border-radius: var(--radius-md); padding: 1.5rem;">
                  <h2 style="font-size: 1.125rem; font-weight: 700; color: var(--color-accent); margin-bottom: 0.75rem;">
                    <?php esc_html_e('Architectural Solution & Implementation', 'sahand-theme'); ?>
                  </h2>
                  <p style="font-size: 0.9375rem; line-height: 1.7; color: var(--color-text-secondary); margin: 0;">
                    <?php echo nl2br(esc_html($solution)); ?>
                  </p>
                </div>
              <?php endif; ?>
            </section>
          <?php endif; ?>

          <div class="entry-content" style="font-size: 1.125rem; line-height: 1.8; color: var(--color-text-secondary);">
            <?php the_content(); ?>
          </div>

        </article>
        <?php
    endwhile;
    ?>
  </div>
</main>

<?php
get_footer();
