<?php
/**
 * Template Name: Engineering Principles & Architecture
 *
 * @package SahandTheme
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
$current_lang = function_exists('sahand_get_current_lang') ? sahand_get_current_lang() : 'fa';
?>

<main id="primary" class="site-main" style="background-color: var(--color-canvas); color: var(--color-text-primary); min-height: 80vh; padding-block: 4rem 6rem; position: relative;">
  
  <!-- Engineering Data Flow Background -->
  <?php get_template_part('template-parts/components/neural-data-flow', null, array('variant' => 'engineering', 'theme' => 'light')); ?>

  <div class="sahand-container" style="position: relative; z-index: 2;">
    
    <header style="margin-bottom: 3.5rem; border-bottom: 1px solid var(--color-border-subtle); padding-bottom: 2rem;">
      <div class="badge badge-stable" style="margin-bottom: 1rem; display: inline-block;">
        <span>DISCIPLINES // ARCHITECTURAL CONSTITUTION</span>
      </div>
      <h1 style="font-size: clamp(2rem, 4vw, 3rem); font-weight: 800; letter-spacing: -0.02em;">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('اصول مهندسی، معماری سیستم‌ها و انضباط فنی');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Mühendislik İlkeleri, Sistem Mimarisi ve Teknik Disiplin');
        } else {
            echo esc_html('Engineering Disciplines, Systems Architecture & Principles');
        }
        ?>
      </h1>
      <p style="font-size: 1.125rem; color: var(--color-text-secondary); max-width: 700px; margin-top: 0.75rem; line-height: 1.7;">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('توسعه بر پایه تفکر سامانه‌ای، دقت ریاضی، معماری دفاع در عمق، و کاهش وابستگی‌های شکننده.');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Sistemik düşünce, matematiksel hassasiyet, derinlemesine savunma ve dayanıklı yazılım mimarisi ilkeleri.');
        } else {
            echo esc_html('Decoupled microstructures, zero-trust cybersecurity, deterministic execution, and sovereign digital product development.');
        }
        ?>
      </p>
    </header>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 2rem; margin-bottom: 4rem;">
      
      <div class="sahand-card">
        <div class="badge badge-tech font-mono" style="margin-bottom: 1rem;">PRINCIPLE // 01</div>
        <h2 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 0.75rem;">
          <?php esc_html_e('Defense-in-Depth Cybersecurity', 'sahand-theme'); ?>
        </h2>
        <p style="font-size: 0.9375rem; color: var(--color-text-secondary); line-height: 1.7;">
          <?php esc_html_e('Every operational boundary is treated as zero-trust. Verification of object-level capabilities, strict cryptographic nonces, atomic concurrency rate limiting, and sanitized contexts protect every ingress.', 'sahand-theme'); ?>
        </p>
      </div>

      <div class="sahand-card">
        <div class="badge badge-tech font-mono" style="margin-bottom: 1rem;">PRINCIPLE // 02</div>
        <h2 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 0.75rem;">
          <?php esc_html_e('Decoupled Modular Architecture', 'sahand-theme'); ?>
        </h2>
        <p style="font-size: 0.9375rem; color: var(--color-text-secondary); line-height: 1.7;">
          <?php esc_html_e('Clean separation between presentation (custom theme), business logic & storage (custom core plugin), and headless APIs prevents single points of failure and platform lock-in.', 'sahand-theme'); ?>
        </p>
      </div>

      <div class="sahand-card">
        <div class="badge badge-tech font-mono" style="margin-bottom: 1rem;">PRINCIPLE // 03</div>
        <h2 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 0.75rem;">
          <?php esc_html_e('Sub-Millisecond Order Routing & Flow', 'sahand-theme'); ?>
        </h2>
        <p style="font-size: 0.9375rem; color: var(--color-text-secondary); line-height: 1.7;">
          <?php esc_html_e('MicroMap price-action engines and algorithmic execution windows designed around London and New York market openings with deterministic risk parameters.', 'sahand-theme'); ?>
        </p>
      </div>

      <div class="sahand-card">
        <div class="badge badge-tech font-mono" style="margin-bottom: 1rem;">PRINCIPLE // 04</div>
        <h2 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 0.75rem;">
          <?php esc_html_e('Native Multilingual Invariance', 'sahand-theme'); ?>
        </h2>
        <p style="font-size: 0.9375rem; color: var(--color-text-secondary); line-height: 1.7;">
          <?php esc_html_e('Persian (RTL), English (LTR), and Turkish (LTR) treated with equal architectural first-class citizenship: native typographic rules, bidirectional CSS layout, and localized SEO hreflang headers.', 'sahand-theme'); ?>
        </p>
      </div>

    </div>

  </div>
</main>

<?php
get_footer();
