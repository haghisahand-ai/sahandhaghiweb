<?php
/**
 * Single Template for sahand_product CPT (Launchpad Products)
 *
 * @package SahandTheme
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
$current_lang = function_exists('sahand_get_current_lang') ? sahand_get_current_lang() : 'fa';
?>

<main id="primary" class="site-main" style="background-color: var(--color-canvas); color: var(--color-text-primary); padding-block: 4rem 6rem;">
  <div class="sahand-container">
    <?php
    while (have_posts()) : the_post();
        $post_id      = get_the_ID();
        $version      = get_post_meta($post_id, '_sahand_product_version', true) ?: '1.0.0';
        $status       = get_post_meta($post_id, '_sahand_product_status', true) ?: 'stable';
        $download_url = get_post_meta($post_id, '_sahand_product_download_url', true);
        $changelog    = get_post_meta($post_id, '_sahand_product_changelog', true);
        ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?> style="max-width: 860px; margin-inline: auto;">
          
          <nav aria-label="<?php esc_attr_e('Breadcrumbs', 'sahand-theme'); ?>" style="margin-bottom: 2rem;">
            <a href="<?php echo esc_url(home_url('/' . $current_lang . '/launchpad/')); ?>" style="color: var(--color-accent); text-decoration: none; font-size: 0.875rem;">
              ← <?php esc_html_e('Back to Launchpad', 'sahand-theme'); ?>
            </a>
          </nav>

          <header style="margin-bottom: 3rem; border-bottom: 1px solid var(--color-border-subtle); padding-bottom: 2rem;">
            <div style="display: flex; gap: 0.75rem; align-items: center; margin-bottom: 1rem;">
              <span class="badge badge-stable" style="text-transform: uppercase;">
                <?php echo esc_html($status); ?>
              </span>
              <span class="font-mono badge badge-tech" style="font-size: 0.8125rem;">
                v<?php echo esc_html($version); ?>
              </span>
            </div>

            <h1 style="font-size: clamp(2.25rem, 5vw, 3.25rem); font-weight: 800; line-height: 1.2;">
              <?php the_title(); ?>
            </h1>

            <?php if ($download_url) : ?>
              <div style="margin-top: 1.5rem;">
                <a href="<?php echo esc_url($download_url); ?>" target="_blank" rel="noopener noreferrer" class="badge badge-stable" style="text-decoration: none; padding: 0.75rem 1.75rem; font-size: 0.9375rem; font-weight: 700; display: inline-flex; align-items: center; gap: 0.5rem;">
                  <span>⬇</span>
                  <span><?php esc_html_e('Download / Access Release', 'sahand-theme'); ?></span>
                </a>
              </div>
            <?php endif; ?>
          </header>

          <div class="entry-content" style="font-size: 1.125rem; line-height: 1.8; color: var(--color-text-secondary); margin-bottom: 3rem;">
            <?php the_content(); ?>
          </div>

          <?php if ($changelog) : ?>
            <section style="background: rgba(2, 132, 199, 0.04); border: 1px solid rgba(2, 132, 199, 0.2); border-radius: var(--radius-md); padding: 1.75rem; margin-top: 2rem;">
              <h2 style="font-size: 1.125rem; font-weight: 700; color: var(--color-accent); margin-bottom: 1rem;">
                <?php esc_html_e('Release Notes & Changelog', 'sahand-theme'); ?>
              </h2>
              <pre class="font-mono" style="font-size: 0.875rem; line-height: 1.7; color: var(--color-text-primary); white-space: pre-wrap; margin: 0; background: transparent; border: none; padding: 0;"><?php echo esc_html($changelog); ?></pre>
            </section>
          <?php endif; ?>

        </article>
        <?php
    endwhile;
    ?>
  </div>
</main>

<?php
get_footer();
