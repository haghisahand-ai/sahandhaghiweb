<?php
/**
 * Archive Template for sahand_insight CPT (Research & Technical Insights)
 *
 * @package SahandTheme
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
$current_lang = function_exists('sahand_get_current_lang') ? sahand_get_current_lang() : 'fa';
?>

<main id="primary" class="site-main" style="background-color: var(--color-canvas); color: var(--color-text-primary); padding-block: 4rem 6rem;">
  <div class="sahand-container">
    
    <header style="margin-bottom: 3.5rem; border-bottom: 1px solid var(--color-border-subtle); padding-bottom: 2rem;">
      <div class="badge badge-tech" style="margin-bottom: 1rem; display: inline-block;">
        <span>PUBLICATIONS // TECHNICAL THOUGHT LEADERSHIP</span>
      </div>
      <h1 style="font-size: clamp(2.25rem, 5vw, 3.5rem); font-weight: 800; line-height: 1.2;">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('دیدگاه‌ها و پژوهش‌های فنی');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Teknik İncelemeler ve Makaleler');
        } else {
            echo esc_html('Technical Insights & Research');
        }
        ?>
      </h1>
      <p style="font-size: 1.125rem; color: var(--color-text-secondary); max-width: 680px; margin-top: 0.75rem; line-height: 1.7;">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('تحلیل‌های عمیق ساختار داده‌ها، امنیت نرم‌افزار، مقیاس‌پذیری و طراحی سیستم‌های توزیع‌شده.');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Yazılım güvenliği, veri yapıları ve ölçeklenebilir sistem mimarisi üzerine kapsamlı teknik yazılar.');
        } else {
            echo esc_html('Deep dives into systems architecture, application security, concurrency patterns, and algorithmic trading systems.');
        }
        ?>
      </p>
    </header>

    <?php if (have_posts()) : ?>
      <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 1.75rem;">
        <?php
        while (have_posts()) : the_post();
            $post_id      = get_the_ID();
            $reading_time = get_post_meta($post_id, '_sahand_insight_reading_time', true) ?: '6';
            $difficulty   = get_post_meta($post_id, '_sahand_insight_difficulty', true) ?: 'intermediate';
            $takeaway     = get_post_meta($post_id, '_sahand_insight_key_takeaway', true);
            ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('sahand-card'); ?> style="display: flex; flex-direction: column; justify-content: space-between;">
              <div>
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                  <span class="badge badge-stable" style="text-transform: uppercase; font-size: 0.75rem;">
                    <?php echo esc_html($difficulty); ?>
                  </span>
                  <span class="font-mono" style="font-size: 0.75rem; color: var(--color-text-tertiary);">
                    ⏱ <?php echo esc_html($reading_time); ?> MIN
                  </span>
                </div>

                <h2 style="font-size: 1.35rem; font-weight: 700; margin-bottom: 0.75rem; line-height: 1.3;">
                  <a href="<?php the_permalink(); ?>" style="color: var(--color-text-primary); text-decoration: none;">
                    <?php the_title(); ?>
                  </a>
                </h2>

                <p style="font-size: 0.9375rem; line-height: 1.6; color: var(--color-text-secondary); margin-bottom: 1.25rem;">
                  <?php
                  if ($takeaway) {
                      echo esc_html(wp_trim_words($takeaway, 22));
                  } else {
                      echo esc_html(wp_trim_words(get_the_excerpt(), 22));
                  }
                  ?>
                </p>
              </div>

              <div style="padding-top: 1rem; border-top: 1px solid var(--color-border-subtle); display: flex; justify-content: space-between; align-items: center;">
                <span class="font-mono" style="font-size: 0.75rem; color: var(--color-text-tertiary);">
                  <?php echo get_the_date('M Y'); ?>
                </span>
                <a href="<?php the_permalink(); ?>" style="color: var(--color-accent); font-weight: 600; font-size: 0.875rem; text-decoration: none;">
                  <?php esc_html_e('Read Thesis', 'sahand-theme'); ?> →
                </a>
              </div>
            </article>
            <?php
        endwhile;
        ?>
      </div>

      <div style="margin-top: 3rem; text-align: center;">
        <?php the_posts_pagination(array('mid_size' => 2)); ?>
      </div>

    <?php else : ?>
      <p style="color: var(--color-text-secondary); font-size: 1.125rem;">
        <?php esc_html_e('No insights published yet.', 'sahand-theme'); ?>
      </p>
    <?php endif; ?>

  </div>
</main>

<?php
get_footer();
