<?php
/**
 * Template Name: Launchpad Products
 *
 * @package SahandTheme
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
$current_lang = function_exists('sahand_get_current_lang') ? sahand_get_current_lang() : 'fa';
?>

<main id="primary" class="site-main" style="background-color: var(--color-canvas); color: var(--color-text-primary); min-height: 80vh; padding-block: 4rem 6rem;">
  <div class="sahand-container">
    
    <header style="margin-bottom: 3.5rem; border-bottom: 1px solid var(--color-border-subtle); padding-bottom: 2rem;">
      <div class="badge badge-stable" style="margin-bottom: 1rem; display: inline-block;">
        <span>RELEASE MATRIX // SOVEREIGN UTILITIES</span>
      </div>
      <h1 style="font-size: clamp(2rem, 4vw, 3rem); font-weight: 800; letter-spacing: -0.02em;">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('پرتابگاه محصولات دیجیتال و ابزارهای مستقل');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Launchpad — Dijital Ürünler ve Bağımsız Araçlar');
        } else {
            echo esc_html('Launchpad — Digital Products & Sovereign Tools');
        }
        ?>
      </h1>
      <p style="font-size: 1.125rem; color: var(--color-text-secondary); max-width: 700px; margin-top: 0.75rem; line-height: 1.7;">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('ابزارهای توسعه‌یافته، پکیج‌های مستقل و نرم‌افزارهای کاربردی با پایش نسخه‌گذاری SemVer.');
        } elseif ($current_lang === 'tr') {
            echo esc_html('SemVer sürüm takipli bağımsız dijital ürünler, yazılım paketleri ve üretim araçları.');
        } else {
            echo esc_html('Production-grade open-source tools, developer utilities, and sovereign products with strict SemVer versioning.');
        }
        ?>
      </p>
    </header>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 2rem;">
      <?php
      $products_query = new WP_Query(array(
          'post_type'      => 'sahand_product',
          'post_status'    => 'publish',
          'posts_per_page' => 20,
          'orderby'        => 'date',
          'order'          => 'DESC',
      ));

      if ($products_query->have_posts()) :
          while ($products_query->have_posts()) : $products_query->the_post();
              $post_id      = get_the_ID();
              $version      = get_post_meta($post_id, '_sahand_product_version', true) ?: '1.0.0';
              $status       = get_post_meta($post_id, '_sahand_product_status', true) ?: 'stable';
              $download_url = get_post_meta($post_id, '_sahand_product_download_url', true);
              $changelog    = get_post_meta($post_id, '_sahand_product_changelog', true);
              ?>
              <article id="post-<?php the_ID(); ?>" <?php post_class('sahand-card'); ?> style="display: flex; flex-direction: column; justify-content: space-between;">
                <div>
                  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                    <span class="badge badge-tech" style="font-family: monospace;">
                      v<?php echo esc_html($version); ?>
                    </span>
                    <span class="badge badge-stable" style="text-transform: uppercase; font-size: 0.75rem;">
                      <?php echo esc_html($status); ?>
                    </span>
                  </div>

                  <h2 style="font-size: 1.375rem; font-weight: 700; margin-bottom: 0.75rem;">
                    <a href="<?php the_permalink(); ?>" style="color: inherit; text-decoration: none;">
                      <?php the_title(); ?>
                    </a>
                  </h2>

                  <div style="font-size: 0.9375rem; color: var(--color-text-secondary); line-height: 1.6; margin-bottom: 1.25rem;">
                    <?php the_excerpt(); ?>
                  </div>

                  <?php if ($changelog) : ?>
                    <div style="background: rgba(0,0,0,0.02); border-radius: var(--radius-sm); padding: 0.75rem; font-family: monospace; font-size: 0.75rem; color: var(--color-text-tertiary); max-height: 80px; overflow-y: auto;">
                      <?php echo nl2br(esc_html($changelog)); ?>
                    </div>
                  <?php endif; ?>
                </div>

                <div style="margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid var(--color-border-subtle); display: flex; justify-content: space-between; align-items: center;">
                  <a href="<?php the_permalink(); ?>" style="color: var(--color-accent); text-decoration: none; font-size: 0.875rem; font-weight: 600;">
                    <?php esc_html_e('Release Notes', 'sahand-theme'); ?> →
                  </a>
                  <?php if ($download_url) : ?>
                    <a href="<?php echo esc_url($download_url); ?>" target="_blank" rel="noopener noreferrer" class="badge badge-stable" style="text-decoration: none;">
                      <?php esc_html_e('Access / Download', 'sahand-theme'); ?>
                    </a>
                  <?php endif; ?>
                </div>
              </article>
              <?php
          endwhile;
          wp_reset_postdata();
      else :
          ?>
          <div class="sahand-card" style="grid-column: 1 / -1; text-align: center; padding: 3rem;">
            <p style="color: var(--color-text-secondary); font-size: 1.125rem;">
              <?php esc_html_e('Product releases are currently in staging validation. Releases will appear here.', 'sahand-theme'); ?>
            </p>
          </div>
          <?php
      endif;
      ?>
    </div>

  </div>
</main>

<?php
get_footer();
