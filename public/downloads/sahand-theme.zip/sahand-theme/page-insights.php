<?php
/**
 * Template Name: Technical Insights & Research
 *
 * @package SahandTheme
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
$current_lang = function_exists('sahand_get_current_lang') ? sahand_get_current_lang() : 'fa';
?>

<main id="primary" class="site-main" style="background-color: var(--color-canvas); color: var(--color-text-primary); min-height: 80vh; padding-block: 4rem 6rem;">
  <div class="sahand-container">
    
    <header style="margin-bottom: 3.5rem; border-bottom: 1px solid var(--color-border-subtle); padding-bottom: 2rem;">
      <div class="badge badge-stable" style="margin-bottom: 1rem; display: inline-block;">
        <span>PUBLICATIONS // TECHNICAL PAPERS & INSIGHTS</span>
      </div>
      <h1 style="font-size: clamp(2rem, 4vw, 3rem); font-weight: 800; letter-spacing: -0.02em;">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('بینش‌های فنی، تحلیل‌های معماری و پژوهش‌ها');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Teknik Makaleler, Mimari Analizler ve Araştırmalar');
        } else {
            echo esc_html('Technical Insights, Architecture Analysis & Research');
        }
        ?>
      </h1>
      <p style="font-size: 1.125rem; color: var(--color-text-secondary); max-width: 700px; margin-top: 0.75rem; line-height: 1.7;">
        <?php
        if ($current_lang === 'fa') {
            echo esc_html('مقالات تحلیلی در حوزه سیستم‌های معاملاتی، امنیت سایبری، الگوهای نرم‌افزاری و هوش مصنوعی.');
        } elseif ($current_lang === 'tr') {
            echo esc_html('Finansal işlem motorları, siber güvenlik, yazılım kalıpları ve yapay zeka üzerine derinlemesine teknik incelemeler.');
        } else {
            echo esc_html('Rigorous technical explorations of distributed systems, algorithmic microstructure, cybersecurity threat modeling, and modern software paradigms.');
        }
        ?>
      </p>
    </header>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 2rem;">
      <?php
      $insights_query = new WP_Query(array(
          'post_type'      => 'sahand_insight',
          'post_status'    => 'publish',
          'posts_per_page' => 20,
          'orderby'        => 'date',
          'order'          => 'DESC',
      ));

      if ($insights_query->have_posts()) :
          while ($insights_query->have_posts()) : $insights_query->the_post();
              $post_id       = get_the_ID();
              $reading_time  = get_post_meta($post_id, '_sahand_insight_reading_time', true) ?: '5';
              $difficulty    = get_post_meta($post_id, '_sahand_insight_difficulty', true) ?: 'intermediate';
              $takeaway      = get_post_meta($post_id, '_sahand_insight_key_takeaway', true);
              $peer_reviewed = get_post_meta($post_id, '_sahand_insight_peer_reviewed', true);
              ?>
              <article id="post-<?php the_ID(); ?>" <?php post_class('sahand-card'); ?> style="display: flex; flex-direction: column; justify-content: space-between;">
                <div>
                  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                    <span class="badge badge-tech font-mono" style="font-size: 0.75rem;">
                      <?php echo esc_html($reading_time); ?> MIN READ
                    </span>
                    <span class="badge badge-stable font-mono" style="text-transform: uppercase; font-size: 0.75rem;">
                      <?php echo esc_html($difficulty); ?>
                    </span>
                  </div>

                  <h2 style="font-size: 1.375rem; font-weight: 700; margin-bottom: 0.75rem;">
                    <a href="<?php the_permalink(); ?>" style="color: inherit; text-decoration: none;">
                      <?php the_title(); ?>
                    </a>
                  </h2>

                  <div style="font-size: 0.9375rem; color: var(--color-text-secondary); line-height: 1.6; margin-bottom: 1.25rem;">
                    <?php the_excerpt(); ?>
                  </div>

                  <?php if ($takeaway) : ?>
                    <div style="background: rgba(0, 0, 0, 0.02); border-left: 3px solid var(--color-accent); padding: 0.75rem; font-size: 0.8125rem; color: var(--color-text-secondary);">
                      <strong><?php esc_html_e('Core Thesis:', 'sahand-theme'); ?></strong>
                      <p style="margin: 0.25rem 0 0;"><?php echo esc_html($takeaway); ?></p>
                    </div>
                  <?php endif; ?>
                </div>

                <div style="margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid var(--color-border-subtle); display: flex; justify-content: space-between; align-items: center;">
                  <a href="<?php the_permalink(); ?>" style="color: var(--color-accent); text-decoration: none; font-size: 0.875rem; font-weight: 600;">
                    <?php esc_html_e('Read Full Analysis', 'sahand-theme'); ?> →
                  </a>
                  <?php if ($peer_reviewed === 'yes') : ?>
                    <span class="badge badge-stable" style="font-size: 0.7rem;">✓ VERIFIED</span>
                  <?php endif; ?>
                </div>
              </article>
              <?php
          endwhile;
          wp_reset_postdata();
      else :
          ?>
          <div class="sahand-card" style="grid-column: 1 / -1; text-align: center; padding: 3rem;">
            <p style="color: var(--color-text-secondary); font-size: 1.125rem;">
              <?php esc_html_e('Technical insights are being authored and reviewed. Check back soon.', 'sahand-theme'); ?>
            </p>
          </div>
          <?php
      endif;
      ?>
    </div>

  </div>
</main>

<?php
get_footer();
